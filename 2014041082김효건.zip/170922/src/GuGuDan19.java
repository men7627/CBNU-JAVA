
public class GuGuDan19 {
	public static void main(String args[])
	{
		for(int dan=2; dan<=19; dan++)
		{
			System.out.println("[" + dan + "]��");
			for(int su=1; su<=19; su++)
			{
				System.out.print(dan + "*" + su + "=" + (dan*su) + " ");
			}
			System.out.println();
		}
	}

}
