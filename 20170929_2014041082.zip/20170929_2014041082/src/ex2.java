
public class ex2 {

	public static void main(String[] args) {
		int[][] coinUnit = {{500,100,50,10},{0,0,0,0}};
		int money = 2680;
		System.out.println("money="+money);
		
		for(int i=0 ; i<coinUnit[0].length ;i++)
		{
			
			coinUnit[1][i] = money / coinUnit[0][i];
			money %= coinUnit[0][i];
		}
		for(int i=0 ; i<coinUnit[1].length ;i++)
		{
			System.out.println(coinUnit[0][i]+"�� : "+coinUnit[1][i]);
		}
	}

}
